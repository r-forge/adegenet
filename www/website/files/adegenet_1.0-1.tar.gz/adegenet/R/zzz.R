.First.lib <- function (lib, pkg){
library.dynam("adegenet", pkg, lib)
  cat("   ##########################\n")
  cat("   ### adegenet is loaded ### \n")
  cat("   ##########################\n\n")
  
  cat(" - to start, type ?adegenet\n")
  cat(" - send questions, bugs, ... to jombart@biomserv.univ-lyon1.fr\n\n")
}
