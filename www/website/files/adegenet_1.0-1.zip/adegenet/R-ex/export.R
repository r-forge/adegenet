### Name: export
### Title: Conversion functions from adegenet to other R packages
### Aliases: genind2genotype genind2hierfstat
### Keywords: manip

### ** Examples

if(require(hierfstat)){

obj <- fstat2genind(system.file("data/diploid.dat",package="hierfstat"))

X <- genind2hierfstat(obj)
X

read.fstat.data(paste(.path.package("hierfstat"),"/data/diploid.dat",sep="",collapse=""),nloc=5)
}
if(require(genetics)){
genind2genotype(obj)
}



