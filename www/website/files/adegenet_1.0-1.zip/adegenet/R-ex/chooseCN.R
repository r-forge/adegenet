### Name: chooseCN
### Title: Function to choose a connection network
### Aliases: chooseCN
### Keywords: spatial utilities

### ** Examples

data(nancycats)
if(require(spdep) & require(ade4)){

par(mfrow=c(2,2))
cn1 <- chooseCN(nancycats$xy,ask=FALSE,type=1)
cn2 <- chooseCN(nancycats$xy,ask=FALSE,type=2)
cn3 <- chooseCN(nancycats$xy,ask=FALSE,type=3)
cn4 <- chooseCN(nancycats$xy,ask=FALSE,type=4)
par(mfrow=c(1,1))
}



