### Name: monmonier
### Title: Boundary detection using Monmonier algorithm
### Aliases: monmonier optimize.monmonier plot.monmonier print.monmonier
### Keywords: multivariate spatial

### ** Examples

## Not run: 
##D require(spdep)
##D require(ade4)
##D 
##D ### non-interactive example
##D 
##D # est-west separation
##D load(system.file("files/mondata1.rda",package="adegenet"))
##D cn1 <- chooseCN(mondata1$xy,type=2,ask=F)
##D mon1 <- monmonier(mondata1$xy,dist(mondata1$x1),cn1$cn,threshold=2)
##D plot(mon1,mondata1$x1)
##D plot(mon1,mondata1$x1,met="greylevel",add.arr=FALSE,col="red",bwd=6,lty=2)
##D 
##D # square in the middle
##D load(system.file("files/mondata2.rda",package="adegenet"))
##D cn2 <- chooseCN(mondata2$xy,type=1,ask=F)
##D mon2 <- monmonier(mondata2$xy,dist(mondata2$x2),cn2$cn,threshold=2)
##D plot(mon2,mondata2$x2,method="greylevel",add.arr=FALSE,bwd=6,col="red",csize=.5)
##D 
##D ### interactive example
##D 
##D # est-west separation
##D xy <- matrix(runif(120,0,10), ncol=2)
##D x1 <- rnorm(60)
##D x1[xy[,1] > 5] <- x1[xy[,1] > 5]+4
##D cn1 <- chooseCN(xy,type=2,ask=F)
##D mon1 <- optimize.monmonier(xy,dist(x1),cn1$cn,ntry=6)
##D 
##D # graphics
##D plot(mon1,x1)
##D plot(mon1,x1,met="greylevel")
##D 
##D # square in the middle
##D x2 <- rnorm(60)
##D sel <- (xy[,1]>3.5 & xy[,2]>3.5 & xy[,1]<6.5 & xy[,2]<6.5)
##D x2[sel] <- x2[sel]+4
##D cn2 <- chooseCN(xy,type=1,ask=F)
##D mon2 <- optimize.monmonier(xy,dist(x2),cn2$cn,ntry=6)
##D 
##D # graphics
##D plot(mon2,x2,method="greylevel",add.arr=F,bwd=6,col="red",csize=.5)
##D 
## End(Not run)



