Fichier de E Paradis. Ne s'ouvre pas avec read.genetix, mais
marcherait avec version de EP.
