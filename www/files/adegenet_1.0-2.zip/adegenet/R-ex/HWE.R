### Encoding: UTF-8

### Name: HWE.test.genind
### Title: Hardy-Weinberg Equilibrium test for multilocus data
### Aliases: HWE.test.genind
### Keywords: manip multivariate

### ** Examples

data(nancycats)
obj <- nancycats
if(require(genetics)){
obj.test <- HWE.test.genind(obj)

# pvalues matrix to have a preview
HWE.test.genind(obj,res.type="matrix")

#more precise view to...
obj.test$fca90$P10
}



