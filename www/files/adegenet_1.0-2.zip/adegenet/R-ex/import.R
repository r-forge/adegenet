### Encoding: UTF-8

### Name: import
### Title: Conversion function for adegenet
### Aliases: import2genind genetix2genind genepop2genind fstat2genind
### Keywords: manip

### ** Examples

genetix2genind(system.file("files/nancycats.gtx",package="adegenet"))

fstat2genind(system.file("files/nancycats.dat",package="adegenet"))

genepop2genind(system.file("files/nancycats.gen",package="adegenet"))

import2genind(system.file("files/nancycats.gtx",
package="adegenet"))

if(require(hierfstat)){
obj <- fstat2genind(system.file("data/diploid.dat",package="hierfstat"))
obj
}



