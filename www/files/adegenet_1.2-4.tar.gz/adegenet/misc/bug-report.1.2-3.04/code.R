## the summary method is no longer found !?!
data(nancycats)
summary(nancycats)
